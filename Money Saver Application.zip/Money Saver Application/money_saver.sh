#!/bin/sh

java -jar money_saver.jar